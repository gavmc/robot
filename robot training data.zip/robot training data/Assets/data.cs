﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class data : MonoBehaviour
{
    public GameObject gate;
    public GameObject wall;
    public GameObject checkpoint;
    public GameObject robot;
    public Material floor_color;

    int gate_count = 3;
    int wall_count = 8;


    void Start()
    {
        StartCoroutine(Create("1"));
    }

    // Update is called once per frame
    void Update()
    {


    }

    IEnumerator Create(string image_name)
    {

        GameObject[] gos = GameObject.FindGameObjectsWithTag("temp");
        foreach (GameObject go in gos)
            Destroy(go);

        Vector3 pos;

        floor_color.color = new Color(Random.Range(0, 124)/255f, Random.Range(0, 66)/255f, Random.Range(0, 11)/255f);


        for (int i = 0; i < wall_count; i++)
        {
            int flip = Random.Range(0, 2);
            if(flip == 1)
            {
                pos = new Vector3(((Random.Range(0, 4)*5)+2.5f)-10, 0, (Random.Range(1, 4)*5)-10);
                
            }
            else
            {
                pos = new Vector3((Random.Range(1, 4)*5)-10, 0,((Random.Range(0, 4)*5)+2.5f)-10);
            }

            GameObject temp_wall = Instantiate(wall, pos, Quaternion.identity);
            temp_wall.tag = "temp";
            temp_wall.layer = 8;
            if(flip == 1)
            {
                temp_wall.transform.Rotate(new Vector3(0, 90, 0));
            }
            
        }


        for (int i = 0; i < gate_count; i++)
        {
            pos = new Vector3(((Random.Range(0, 4)*5)+2.5f)-10, 0, ((Random.Range(0, 4)*5)+2.5f)-10);

            GameObject temporary = Instantiate(gate, pos, Quaternion.identity);
            temporary.tag = "temp";
            temporary.layer = 12;
        }

        pos = new Vector3(((Random.Range(0, 4) * 5) + 2.5f) - 10, 0, ((Random.Range(0, 4) * 5) + 2.5f) - 10);
        GameObject temp_ = Instantiate(checkpoint, pos, Quaternion.identity);
        temp_.tag = "temp";
        temp_.layer = 10;

        pos = new Vector3(((Random.Range(0, 4) * 5) + 2.5f) - 10, 0, ((Random.Range(0, 4) * 5) + 2.5f) - 10);
        GameObject temp_robot = Instantiate(robot, pos, Quaternion.identity);
        temp_robot.transform.Rotate(new Vector3(0, 90*Random.Range(0, 4), 0));
        temp_robot.tag = "temp";
        temp_robot.layer = 11;


        ScreenCapture.CaptureScreenshot("D:/unity/Unity games/robot training data/screenshots/raw/"+image_name +".png");
        yield return new WaitForEndOfFrame();
        Camera cam = robot.transform.GetChild(1).transform.GetChild(0).gameObject.GetComponent<Camera>();
        yield return new WaitForEndOfFrame();
        cam.cullingMask = 1 << LayerMask.NameToLayer("wall");
        ScreenCapture.CaptureScreenshot("D:/unity/Unity games/robot training data/screenshots/wall/" + image_name + ".png");
        /*
        yield return new WaitForEndOfFrame();
        cam.cullingMask = 1 << LayerMask.NameToLayer("ring");
        ScreenCapture.CaptureScreenshot("D:/unity/Unity games/robot training data/screenshots/ring/" + image_name + ".png");
        yield return new WaitForEndOfFrame();
        cam.cullingMask = 1 << LayerMask.NameToLayer("checkpoint");
        ScreenCapture.CaptureScreenshot("D:/unity/Unity games/robot training data/screenshots/checkpoint/" + image_name + ".png");
        yield return new WaitForEndOfFrame();
        cam.cullingMask = 1 << LayerMask.NameToLayer("gate");
        ScreenCapture.CaptureScreenshot("D:/unity/Unity games/robot training data/screenshots/gate/" + image_name + ".png");
        */

    }
}
