﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class data : MonoBehaviour
{
    public GameObject gate;
    public GameObject wall;
    public GameObject checkpoint;
    public GameObject robot;

    int gate_count = 3;
    int wall_count = 8;


    void Start()
    {
        Create();
    }

    // Update is called once per frame
    void Update()
    {


    }

    void Create()
    {
        Vector3 pos;


        for (int i = 0; i < wall_count; i++)
        {
            int flip = Random.Range(0, 2);
            if(flip == 1)
            {
                pos = new Vector3(((Random.Range(0, 4)*5)+2.5f)-10, 0, (Random.Range(1, 4)*5)-10);
                
            }
            else
            {
                pos = new Vector3((Random.Range(1, 4)*5)-10, 0,((Random.Range(0, 4)*5)+2.5f)-10);
            }

            GameObject temp_wall = Instantiate(wall, pos, Quaternion.identity);
            if(flip == 1)
            {
                temp_wall.transform.Rotate(new Vector3(0, 90, 0));
            }
            Debug.Log(pos);
        }


        for (int i = 0; i < gate_count; i++)
        {
            pos = new Vector3(((Random.Range(0, 4)*5)+2.5f)-10, 0, ((Random.Range(0, 4)*5)+2.5f)-10);

            Instantiate(gate, pos, Quaternion.identity);
        }

        pos = new Vector3(((Random.Range(0, 4) * 5) + 2.5f) - 10, 0, ((Random.Range(0, 4) * 5) + 2.5f) - 10);
        Instantiate(checkpoint, pos, Quaternion.identity);

        pos = new Vector3(((Random.Range(0, 4) * 5) + 2.5f) - 10, 0, ((Random.Range(0, 4) * 5) + 2.5f) - 10);
        GameObject temp_robot = Instantiate(robot, pos, Quaternion.identity);
        temp_robot.transform.Rotate(new Vector3(0, 90*Random.Range(0, 4), 0));


    }
}
